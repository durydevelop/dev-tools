SOAP RPC variable polymorphic parameters example.

Although rarely used, the SOAP RPC encoding specification supports variable
parameter lists. In addition, parameters can be polymorphic. Both features are
demonstrated in this example. Because dynamic type binding is required, this
feature is only supported in C++.

