t__gmt(time_t*);
